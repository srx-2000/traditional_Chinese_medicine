#第一种运行方法
import os
os.system('scrapy crawl medicine')
#第二种运行方法
# from scrapy import cmdline
# cmdline.execute('scrapy crawl medicine'.split())